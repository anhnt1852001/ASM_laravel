<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Room;
use App\Models\Room_service;
use App\Models\Service;
use Illuminate\Support\Facades\DB;


class RoomController extends Controller
{
    public function __construct(Room $rooms, Service $services)
    {
        $this->room = $rooms;
        $this->service = $services;
    }
    public function index(Request $request){
        $services = Room::with('services')->get();
        $pagesize = 20;
        $searchData = $request->except('page');
        if(count($request->all()) == 0){
            // Lấy ra danh sách sản phẩm & phân trang cho nó
            $rooms = Room::paginate($pagesize);
        } else {
            $roomQuery = Room::where('room_no', 'like', "%" .$request->keyword . "%");
            if($request->has('order_by') && $request->order_by > 0){
                if($request->order_by == 1){
                    $roomQuery = $roomQuery->orderBy('room_no');
                }else if($request->order_by == 2){
                    $roomQuery = $roomQuery->orderByDesc('room_no');
                }else if($request->order_by == 3){
                    $roomQuery = $roomQuery->orderBy('price');
                }else if($request->order_by == 4) {
                    $roomQuery = $roomQuery->orderByDesc('price');
                }else if($request->order_by == 5) {
                    $roomQuery = $roomQuery->orderBy('floor');
                }else {
                    $roomQuery = $roomQuery->orderByDesc('floor');
                }
            }
            $rooms = $roomQuery->paginate($pagesize)->appends($searchData);
        }
        return view('admin.rooms.list', ['rooms' => $rooms,'services' => $services,  'searchData' => $searchData]);
    }
    public function remove(Request $request){
        $id = $request->id;
        $deleteRoom = Room::where('id',$id)->delete();//xóa id của bảng room
        $deleteRoomServiceByRoomId = Room_service::where('room_id',$id)->delete();//xóa các service liên quan tới id của room ( xóa service id thuộc room id)
        return redirect(route('room.index'));
    }


    public function addForm(){
        $service = Service::all();
        return view('admin.rooms.add-form', ['service' =>$service]);
    }

    public function saveAdd(Request $request){
        $model = new Room();
        $model->fill($request->all());
        // upload ảnh
        if($request->hasFile('uploadfile')){
            $model->image  = $request->file('uploadfile')->storeAs('uploads/rooms', uniqid() . '-' . $request->uploadfile->getClientOriginalName());
        }

        $model->save();
        return redirect(route('room.index'));
    }


    public function editForm($id) {
        $model = Room::find($id);
        if(!$model) {
            return redirect()->back();
        }
        return view('admin.rooms.edit-form', compact('model'));
    }
    public function saveEdit($id, Request $request){
        $model = Room::find($id);
        if(!$model){
            return redirect()->back();
        }
        $model->fill($request->all());
        // upload ảnh
        if($request->hasFile('uploadfile')){
            $model->image = $request->file('uploadfile')->storeAs('uploads/rooms', uniqid() . '-' . $request->uploadfile->getClientOriginalName());
        }
        $model->save();
        return redirect(route('room.index'));
    }
}
