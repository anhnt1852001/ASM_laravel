<?php $__env->startSection('content'); ?>
<form action="" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên Room</label>
                <input type="text" name="room_no" class="form-control" value="<?php echo e($model->room_no); ?>">
            </div>
            <div class="form-group">
                <label for="">Floor</label>
                <input type="text" name="floor" class="form-control" value="<?php echo e($model->floor); ?>">
            </div>
            <div class="form-group">
                <label for="">Giá</label>
                <input type="text" name="price" class="form-control" value="<?php echo e($model->price); ?>">
            </div>
        </div>
        <div class="col-6">
            <div class="add-product-preview-img">
                <img src="<?php echo e(asset(''.$model->image)); ?>" alt="">
            </div>
            <div class="form-group">
                <label for="">Ảnh sản phẩm</label>
                <input type="file" name="uploadfile" class="form-control">
            </div>
        </div>
        <div class="col-12">
            <div class="form-group">
                <label for="">Chi tiết sản phẩm:</label>
                <textarea name="detail" class=form-control  rows="10"><?php echo e($model->detail); ?></textarea>
            </div>
        </div>
        <div class="text-right">
            <button type="submit" class="btn btn-primary">Lưu</button>
            <a href="<?php echo e(route('room.index')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </div>

</form>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php3\ASM_laravel\resources\views/admin/rooms/edit-form.blade.php ENDPATH**/ ?>