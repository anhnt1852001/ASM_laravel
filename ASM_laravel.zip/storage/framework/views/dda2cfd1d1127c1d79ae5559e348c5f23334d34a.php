<?php $__env->startSection('content'); ?>
<form action="" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên Dịch vụ</label>
                <input type="text" name="name" class="form-control">
            </div>
        </div>
        <div class="col-6">
            <div class="add-product-preview-img">

            </div>
            <div class="form-group">
                <label for="">Icon</label>
                <input type="file" name="uploadfile" class="form-control">
            </div>
        </div>

        <div class="text-right">
            <button type="submit" class="btn btn-primary">Lưu</button>
            <a href="<?php echo e(route('service.index')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </div>

</form>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php3\ASM_laravel\resources\views/admin/services/add-form.blade.php ENDPATH**/ ?>