<?php $__env->startSection('content'); ?>

<form action="" method="get">
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên Dịch vụ</label>
                <input class="form-control" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
            </div>
        </div>
        <div class="col-6">
            <div>
                <label for="">Sắp Xếp Theo</label>
                <select class="form-control" name="order_by" id="">
                    <option value="0">Mặc định</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 1): ?> selected <?php endif; ?>  value="1">Tên alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 2): ?> selected <?php endif; ?>  value="2">Tên giảm dần alphabet</option>
                </select>
            </div>
        </div>
    </div>
    <div class="text-center mb-2">
        <button type="submit" class="btn btn-primary">Tìm Kiếm</button>
    </div>
</form>

<div class="row">
    <table class="table table-striped">
        <thead>
            <th>STT</th>
            <th>Tên dịch vụ</th>
            <th>Icon</th>
            <th>
                <a href="<?php echo e(route('service.add')); ?>" class="btn btn-primary">Tạo mới</a>
            </th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e((($services->currentPage()-1)*20) + $loop->iteration); ?></td>
                <td><?php echo e($s->name); ?></td>
                <td><img src="<?php echo e(asset( 'storage/' . $s->icon)); ?>" width="70" /></td>
                <td>
                    <a href="<?php echo e(route('service.edit', ['id' => $s->id])); ?>" class="btn btn-danger">Sửa</a>
                    <a href="<?php echo e(route('service.remove', ['id' => $s->id])); ?>" class="btn btn-danger">Xóa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <div class="d-flex justify-content-end">
        <?php echo e($services->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php3\ASM_laravel\resources\views/admin/services/list.blade.php ENDPATH**/ ?>